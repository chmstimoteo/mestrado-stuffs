/*
 * rastrigin.h
 *
 *  Created on: 31/10/2012
 *      Author: cristovao
 */

#ifndef RASTRIGIN_H_
#define RASTRIGIN_H_

#define UPPER_BOUND 5.12
#define LOWER_BOUND -5.12

#include "ga.h"

double rastrigin_fitness (struct ga_algorithm *ga, double *vector);
double rastrigin_fitness_pso (struct pso_algorithm *pso, double *vector);

#endif /* RASTRIGIN_H_ */
