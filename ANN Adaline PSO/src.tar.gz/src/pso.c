
#include "pso.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

void pso_init (struct pso_algorithm *pso) {



}

void pso_random_init_population (struct pso_algorithm *pso) {
	uint32_t i, j;
	
	for (i=0; i < pso->population_size; i++){
		for (j=0; j<pso->var_number; j++){
			pso->population[i]->p_best[j] = pso->population[i]->current_position[j] = 
				LOWER_BOUND + (pso_generate_random()*UPPER_BOUND);
		}
		pso->population[i]->current_speed[j] = 0.0f;
		pso->population[i]->fitness = pso->fit_function(pso, pso->population[i]->current_position);
	}

	return ;
}

double pso_generate_random (void) {
	return ((double)random()/(double)RAND_MAX);
}

//
void pso_update_particle_position (struct pso_algorithm *pso) {



}

// Inicializar a vizinhan�a (lista)
void define_neighborhood () {


}

//Calculo gbest global
void pso_calcutate_particle_gbest_global (struct pso_algorithm *pso, struct neighborhood *neighborhood) {
	for ( ;neighborhood->next != NULL; ) {
		neighborhood->nbest = (neighborhood->current->fitness > neighborhood->nbest) ? 
			neighborhood->current->fitness : neighborhood->nbest;
	}
}

//Calculo gbest local
void pso_calcutate_particle_gbest_local (struct pso_algorithm *pso, struct neighborhood **neighborhood) {
}

//Calculo gbest focal (estrela)
void pso_calcutate_particle_gbest_focal (struct pso_algorithm *pso, struct neighborhood **neighborhood) {
}