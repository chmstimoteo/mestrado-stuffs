
#include "ga.h"
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>
#include <math.h>

void ga_sort (struct ga_algorithm *ga, uint32_t number) {
	uint32_t i, j;
	struct chromossome *temp;

	for (i = number - 1; i > 0; i--) {
		for (j = 0; j < i; j++) {
			if (ga->carac_vector[j]->fitness > ga->carac_vector[i]->fitness) {
				temp = ga->carac_vector[i];
				ga->carac_vector[i] = ga->carac_vector[j];
				ga->carac_vector[j] = temp;

			}
		}
	}

	return ;
}

struct chromossome *ga_generate_chromossome (struct ga_algorithm *ga) {
	struct chromossome *c;

	c = (struct chromossome *)malloc(sizeof(struct chromossome));
	assert (c != NULL);
	c->values = (double *)malloc(sizeof(double)*ga->carac_number);
	assert (c->values != NULL);

	return c;
}

void ga_clean_chromossome (struct chromossome *c) {

	return ;
	assert (c != NULL);
	free (c->values);
	free (c);
}

void ga_init (struct ga_algorithm *ga) {

	uint32_t i;

	ga->carac_vector = (struct chromossome **)malloc(sizeof(struct chromossome *)*(ga->population + ga->offspring));
	assert (ga->carac_vector != NULL);

	for (i = 0; i < ga->population; i++) {
		ga->carac_vector[i] = ga_generate_chromossome(ga);
	}
	for (i = ga->population; i < ga->population + ga->offspring; i++)
		ga->carac_vector[i] = NULL;

	return ;
}

void ga_clean (struct ga_algorithm *ga) {

	return ;
	uint32_t i;

	assert (ga->carac_vector != NULL);

	for (i = 0; i < ga->population; i++) {
		ga_clean_chromossome(ga->carac_vector[i]);
		ga->carac_vector[i] = NULL;
	}

	ga->carac_vector = NULL;

	return ;
}

void ga_init_vector (struct ga_algorithm *ga, double lower_bound, double upper_bound) {

	uint32_t i, j;

	assert (ga->carac_vector != NULL);

	for (i = 0; i < ga->population; i++) {
		for (j = 0; j < ga->carac_number; j++) {
			ga->carac_vector[i]->values[j] = ((upper_bound - lower_bound) * ga_generate_random() + lower_bound);
		}
		ga->carac_vector[i]->fitness = ga->fit_function(ga, ga->carac_vector[i]->values);
	}

	for (i = ga->population; i < (ga->population + ga->offspring); i++)
		ga->carac_vector[i] = NULL;

	return ;
}

void ga_print_vector (struct ga_algorithm *ga) {

	uint32_t i, j;

	assert (ga->carac_vector != NULL);

	for (i = 0; i < ga->population; i++) {
		printf ("ga->carac_vector[%u] = [ ", i);
		for (j = 0; j < ga->carac_number; j++) {
			printf ("%.4lf ", ga->carac_vector[i]->values[j]);
		}
		printf ("] - FITNESS: %.4lf\n", ga->carac_vector[i]->fitness);
	}

	return;
}

double ga_generate_random (void) {

	return ((double)random()/(double)RAND_MAX);
}

