#ifndef OPERATORS_H
#define OPERATORS_H

#include "ga.h"

void survival_elitism (struct ga_algorithm *ga);
void survival_roullete (struct ga_algorithm *ga);

struct chromossome * crossover_one_point (struct ga_algorithm *ga, struct chromossome *ind1, struct chromossome *ind2);
struct chromossome * crossover_two_points (struct ga_algorithm *ga, struct chromossome *ind1, struct chromossome *ind2);
struct chromossome * crossover_random_points (struct ga_algorithm *ga, struct chromossome *ind1, struct chromossome *ind2);

struct chromossome * mutation_uniform (struct ga_algorithm *ga, struct chromossome *ind, double lower_bound, double upper_bound);
struct chromossome * mutation_gaussian (struct ga_algorithm *ga, struct chromossome *ind, double lower_bound, double upper_bound);
struct chromossome * mutation_cauchy (struct ga_algorithm *ga, struct chromossome *ind, double lower_bound, double upper_bound);

#endif
