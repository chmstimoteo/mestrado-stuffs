
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "ga.h"
#include "operators.h"
#include "rastrigin.h"

int main (int argc, char ** argv) {
	struct pso_algorithm pso = {
		population_size: 5, //5,20,50
		var_number: 30,
		c1: 2.5, //decaimento linear at� 1.5
		c2: 1.5, //crescimento linear at� 2.5
		r1: 0.5,
		r2: 0.5,
		inertia_weight: 0.8,
		g_best : NULL
		
		fit_function: rastrigin_fitness,
		update_position: pso_update_particle_position,
		//incluir comunicacao e funcao que define parametros??
		population: NULL
	};
	
	uint32_t num_iter, pop_size, param_lifecycle;
	int32_t fd;
	uint32_t rand_seed;
	
	if(argc != 3){
	fprintf (stderr, "Erro ao executar; n�mero de elementos incorreto!\n");
	fprintf (stderr, "Por favor execute novamente:\n");
	fprintf (stderr, "e.g.: %s num_iter pop_size param_lifecycle\n", argv[0]);

	return 1;
	}
	
	num_iter = atoi(argv[1]);
	pso.population_size = atoi(argv[2]);
	param_lifecycle = atoi(argv[3]);
	
	switch (param_lifecycle) {
		case 2:
			// caso 2
			pso.c1 = 0.0f;
			pso.c2 = 0.0f;
			pso.r1 = 0.0f;
			pso.r2 = 0.0f;
			pso.inertia_weight = 0.0f;
			break;
		case 3:
			//caso 3
			pso.c1 = 0.0f;
			pso.c2 = 0.0f;
			pso.r1 = 0.0f;
			pso.r2 = 0.0f;
			pso.inertia_weight = 0.0f;
			break;
		case 1:
		default:
			//caso base
			pso.c1 = 0.0f;
			pso.c2 = 0.0f;
			pso.r1 = 0.0f;
			pso.r2 = 0.0f;
			pso.inertia_weight = 0.0f;
			break;
	}
	
	// Monta a seed totalmente aleat�ria
	fd = open ("/dev/urandom", O_RDONLY);
	if (fd < 0) { fprintf (stderr, "Erro abrindo /dev/urandom\n"); return 1;}
	read (fd, &rand_seed, sizeof(uint32_t));
	close (fd);
	srandom (rand_seed);
	
	//Inicializa o PSO
	
	//Define o tipo de Comunicacao
	
	for (; num_iter > 0; --num_iter) {
	
		//Calcuta g_best
		
		// Atualiza velocidade e posi�ao
		
		// Atualiza fitness
	
	}
	
	return 0;
}