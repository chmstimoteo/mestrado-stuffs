#ifndef PSO_H
#define PSO_H

struct pso_algorithm;
struct particle;
struct neighborhood;

struct pso_algorithm {
	uint32_t population_size;
	uint32_t var_number;
	double c1; 
	double c2;
	double r1; //sequencia aleatoria uniforme [0..1]
	double r2; //sequencia aleatoria uniforme [0..1]
	double inertia_weight; // numero entre [0..1]
	double *g_best;
	
	double (*fit_function) (struct pso_algorithm *pso, double *vector);
	void (*update_position)(struct pso_algorithm *pso, struct particle *particle);
	
	//TODO: Verificar viabilidade de ser unidimensional
	struct particle **population;
};

struct particle {
	double *current_position;
	double *current_speed;
	double *p_best;
	double fitness;
};

//Vizinhan�a implementada na forma de uma lista simples
struct neighborhood_List { 
	struct particle *current;
	struct particle *next;
	double *nbest; //neighborhood best fitness
};

struct treeNode {
	struct particle *current;
	struct particle *parent;
};

struct neighbohood_Tree {
	struct treeNode *root;
	struct treeNode **children;
};

void pso_init ();
void pso_random_init_population_position ();
void pso_init_population ();
double pso_generate_random (void);
void pso_update_particle_position ();
void define_neighborhood ();
void pso_calcutate_particle_gbest ();
#endif