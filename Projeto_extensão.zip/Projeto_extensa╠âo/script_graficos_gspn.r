###GSPN###

## Remover todos os objetos criados da memoria

rm(list=ls(all=TRUE))

## Setar o diretorio de trabalho

setwd("/Volumes/CADU_MSC/Mestrado/1o.\ semestre/ADS/Projeto_extensão/")

##  Leitura dos Dados

resultados <- read.table("resultados.txt")

ut_quick <- c(resultados[1:7,1])
tp_quick <- c(resultados[1:7,2])

ut_merge <- c(resultados[8:14,1])
tp_merge <- c(resultados[8:14,2])


## Plot dos graficos [quick quickThreads merge mergerThreads]

x <- c(1, 2, 4, 8, 16, 32, 64) 

png("gspn_quick_v3.png")
plot(x, ut_quick, type = "o", ylim=c(0,8), xaxt="n", lty = 1, lwd = "3", col = "blue", xlab="Número de threads", ylab="", main=expression(italic(Quicksort)*""))
lines(x, tp_quick, type = "o", lty = 2, lwd = "3", col = "red", pch=4, xaxt="n")
legend("topleft", inset=.05, c(expression(""*italic(Utilization)), expression(""*italic(Throughput)*"(am/ms)")), col= c("blue", "red"), lty=c(1,2), lwd=c("3","3"), pch=c(1,4))
axis(1, at = x, labels = x) 
dev.off()

png("gspn_merge_v3.png")
plot(x, ut_merge, type = "o", ylim=c(0,8), xaxt="n", lty = 1, lwd = "3", col = "cyan", xlab="Número de threads", ylab="", main=expression(italic(Merge)*" "*italic(sort)*""))
lines(x, tp_merge, type = "o", lty = 2, lwd = "3", col = "magenta", pch=4, xaxt="n")
legend("topleft", inset=.05, c(expression(""*italic(Utilization)), expression(""*italic(Throughput)*"(am/ms)")), col= c("cyan", "magenta"), lty=c(1,2), lwd=c("3","3"), pch=c(1,4))
axis(1, at = x, labels = x) 
dev.off()




