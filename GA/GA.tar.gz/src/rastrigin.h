/*
 * rastrigin.h
 *
 *  Created on: 31/10/2012
 *      Author: cristovao
 */

#ifndef RASTRIGIN_H_
#define RASTRIGIN_H_

#include "ga.h"

double rastrigin_fitness (struct ga_algorithm *ga, double *vector);

#endif /* RASTRIGIN_H_ */
