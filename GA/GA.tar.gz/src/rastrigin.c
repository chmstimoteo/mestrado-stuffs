/*
 * rastrigin.c
 *
 *  Created on: 31/10/2012
 *      Author: cristovao
 */

#include <math.h>
#include "ga.h"
#include "rastrigin.h"

static const double A = 10.0f;

double rastrigin_fitness (struct ga_algorithm *ga, double *vector) {
	uint32_t i;
	double r = 0.0f;

	for (i = 0; i < ga->carac_number; i++)
		r += (vector[i]*vector[i] - A*cos(2.0f*M_PI*vector[i]));

	r += A*(double)ga->carac_number;

	return r;
}

