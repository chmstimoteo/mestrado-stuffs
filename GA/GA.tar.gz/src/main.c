
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "ga.h"
#include "operators.h"
#include "rastrigin.h"

int main (int argc, char ** argv) {

	struct ga_algorithm ga = {
//		population: 		30,
		offspring:			4,
		carac_number:		30,
//		mutation_index: 	0.2,
//		crossover_index: 	0.9,

		fit_function: 		rastrigin_fitness,
//		crossover_function:	crossover_two_points,
//		mutation_function:	mutation_uniform,
		survival_function:	survival_elitism,

		carac_vector: 		NULL
	};

	int iter, i, offset, num_iter, temp;
	int fd;
	uint32_t rand_seed;

	/* A sequencia é: Numero de iterações, populacao, indice de mutacao
	 * indice de crossover, tipo de mutacao
	 */	

	if (argc != 7) {
		fprintf (stderr, "Erro ao executar; número de elementos incorreto!\n");
		fprintf (stderr, "Por favor execute novamente:\n");
		fprintf (stderr, "e.g.: %s num_iter pop mut_index cross_index tipo_crossover tipo_mutacao\n", argv[0]);

		return 1;

	}

	num_iter = atoi (argv[1]);
	ga.population = atoi (argv[2]);
	ga.mutation_index = atof (argv[3]);
	ga.crossover_index = atof (argv[4]);
	temp = atoi (argv[5]);
	switch (temp) {
		case 2:
			ga.crossover_function = crossover_two_points;
			break;
		case 3:
			ga.crossover_function = crossover_random_points;
			break;
		case 1:
		default:
			ga.crossover_function = crossover_one_point;
			break;
	}
	temp = atoi(argv[6]);
	switch (temp) {
		case 2:
			ga.mutation_function = mutation_gaussian;
			break;
		case 1:
		default:
			ga.mutation_function = mutation_uniform;
			break;
	}

	// Monta a seed totalmente aleatória
	fd = open ("/dev/urandom", O_RDONLY);
	if (fd < 0) { fprintf (stderr, "Erro abrindo /dev/urandom\n"); return 1;}
	read (fd, &rand_seed, sizeof(uint32_t));
	close (fd);
	srandom (rand_seed);

	ga_init (&ga);
	ga_init_vector (&ga, -5.12, 5.12);

	for (iter = 0; iter < num_iter; iter++) {
		ga_sort(&ga, ga.population);

		// Imprime o melhor fitness desta iteração
//		ga_print_vector(&ga);
//		printf ("\n\n");
		printf ("%f\n", ga.carac_vector[0]->fitness);
		if (ga.carac_vector[0]->fitness < 0.01) {
			printf ("\n\n");
			for (i = 0; i < ga.carac_number; i++)
				printf ("%lf ");
			printf ("\n\n");
			return 0;
		}

		// Crossover
		if (ga_generate_random() < ga.crossover_index) {

			for (i = 0; i < ga.offspring / 2; i++) {
				ga.carac_vector[ga.population + offset + i] = ga.crossover_function(&ga, ga.carac_vector[2*i], ga.carac_vector[2*i + 1]);
			}

			ga_sort(&ga, ga.population + (ga.offspring/2));
		}

		// Mutation
		if (ga_generate_random() < ga.mutation_index) {
			for (offset = 0; offset < ga.offspring; offset++)
				if (ga.carac_vector[ga.population + offset] == NULL)
					break;

			for (i = 0; i < (ga.offspring/2); i++)
				ga.carac_vector[ga.population + offset + i] = ga.mutation_function(&ga, ga.carac_vector[i], -5.12, 5.12);

			ga_sort(&ga, ga.population + offset + i);
		}

		// Survival
		ga.survival_function(&ga);
	}

	ga_clean (&ga);

	return 0;
}

