#ifndef GA_H
#define GA_H

#include <stdint.h>

struct ga_algorithm;
struct chromossome;

struct ga_algorithm {
	uint32_t population;
	uint32_t offspring;
	uint32_t carac_number;
	double mutation_index;
	double crossover_index;

	double (*fit_function)(struct ga_algorithm *ga, double *vector);
	struct chromossome *(*crossover_function)(struct ga_algorithm *ga, struct chromossome *ind1, struct chromossome *ind2);
	struct chromossome *(*mutation_function)(struct ga_algorithm *ga, struct chromossome *ind, double lower_bound, double upper_bound);
	void (*survival_function)(struct ga_algorithm *ga);

	struct chromossome **carac_vector;
};

struct chromossome {
	double fitness;
	double *values;
};

void ga_init (struct ga_algorithm *ga);
void ga_clean (struct ga_algorithm *ga);
void ga_init_vector (struct ga_algorithm *ga, double lower_bound, double upper_bound);
void ga_print_vector (struct ga_algorithm *ga);
double ga_generate_random(void);
void ga_sort (struct ga_algorithm *ga, uint32_t number);
struct chromossome *ga_generate_chromossome (struct ga_algorithm *ga);
void ga_clean_chromossome (struct chromossome *chromossome);
#endif

