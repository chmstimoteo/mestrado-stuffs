/*
 * operators.c
 *
 *  Created on: 31/10/2012
 *      Author: cristovao
 */

#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>
#include <assert.h>

#include "ga.h"
#include "operators.h"

void survival_elitism (struct ga_algorithm *ga) {
	return ;
}

void survival_roullete (struct ga_algorithm *ga) {
	return ;
}

struct chromossome * crossover_one_point (struct ga_algorithm *ga, struct chromossome *ind1, struct chromossome *ind2) {
	uint32_t pos, i;
	struct chromossome *ret;

	pos = random() % ga->carac_number;
	ret = ga_generate_chromossome(ga);

	for (i = 0; i < pos; ret->values[i] = ind1->values[i], i++);
	for (i = pos; i < ga->carac_number; ret->values[i] = ind2->values[i], i++);

	ret->fitness = ga->fit_function(ga, ret->values);
	return ret;
}

struct chromossome * crossover_two_points (struct ga_algorithm *ga, struct chromossome *ind1, struct chromossome *ind2) {
	uint32_t pos1, pos2, i;
	struct chromossome *ret;

	pos1 = pos2 = 0;
	while (pos1 >= pos2) {
		pos1 = random() % ga->carac_number;
		pos2 = random() % ga->carac_number;
	}

	ret = ga_generate_chromossome(ga);

	for (i = 0; i < pos1; ret->values[i] = ind1->values[i], i++);
	for (i = pos1; i < pos2; ret->values[i] = ind2->values[i], i++);
	for (i = pos2; i < ga->carac_number; ret->values[i] = ind1->values[i], i++);

	ret->fitness = ga->fit_function(ga, ret->values);
	return ret;
}

struct chromossome * crossover_random_points (struct ga_algorithm *ga, struct chromossome *ind1, struct chromossome *ind2) {
	uint32_t i;
	struct chromossome *ret;

	ret = ga_generate_chromossome(ga);

	for (i = 0; i < ga->carac_number; i++) {
		if (random() % 2)
			ret->values[i] = ind1->values[i];
		else
			ret->values[i] = ind2->values[i];
	}

	ret->fitness = ga->fit_function(ga, ret->values);
	return ret;
}

struct chromossome *mutation_uniform (struct ga_algorithm *ga, struct chromossome *ind, double lower_bound, double upper_bound)
{
	uint32_t i, idx;
	struct chromossome *ret;

	idx = random() % ga->carac_number;
	ret = ga_generate_chromossome(ga);

	for (i = 0; i < ga->carac_number; ret->values[i] = ind->values[i], i++);
	ret->values[idx] = (upper_bound - lower_bound) * ga_generate_random() + lower_bound;
	ret->fitness = ga->fit_function(ga, ret->values);

	return ret;
}

struct chromossome *mutation_gaussian (struct ga_algorithm *ga, struct chromossome *ind, double lower_bound, double upper_bound)
{
	uint32_t i, idx;
	struct chromossome *ret;

	idx = random() % ga->carac_number;
	ret = ga_generate_chromossome(ga);

	for (i = 0; i < ga->carac_number; ret->values[i] = ind->values[i], i++);
	ret->values[idx] += (ga_generate_random() - 0.5) * 2 * (upper_bound - lower_bound);
	ret->fitness = ga->fit_function(ga, ret->values);

	return ret;
}

struct chromossome *mutation_cauchy (struct ga_algorithm *ga, struct chromossome *ind, double lower_bound, double upper_bound)
{
	// TODO: Implementar
	return NULL;
}

