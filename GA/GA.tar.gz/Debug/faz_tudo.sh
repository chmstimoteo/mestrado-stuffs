#!/bin/bash

for pop in 30 50; do
	for mut_idx in .1 .5; do
		for crs_idx in .9 .7; do
			for tipo_crs in 1 2 3; do
				for tipo_mut in 1 2; do
					echo "Executando com $pop $mut_idx $crs_idx $tipo_crs $tipo_mut..."
					./executar.sh 60000 $pop $mut_idx $crs_idx $tipo_crs $tipo_mut
				done
			done
		done
	done
done 
