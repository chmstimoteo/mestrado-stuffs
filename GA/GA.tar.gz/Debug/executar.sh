#!/bin/bash

# Sequencia: Iteracoes Populacao TaxaMutacao TaxaCruzamento TipoCruzamento TipoMutacao
OUTFILE="GA_$1_$2_$3_$4_$5_$6"
EXTENSION="txt"

for i in $(seq 1 30); do ./GA $@ > "saida/${OUTFILE}_exec_${i}.${EXTENSION}" & done

A=$(ps | egrep 'GA')
while [ ! "$A" = "" ]; do A=$(ps | egrep 'GA'); sleep 1 ; done
